<?php
session_start();

// Generate a random 3-digit OTP
$otp = rand(000, 999);


$email = $_POST['email']; 



$_SESSION['otp'] = $otp;
$_SESSION['email'] = $email;

// Redirect to OTP verification page
header("Location: otp_verification.php");
exit;
?>
