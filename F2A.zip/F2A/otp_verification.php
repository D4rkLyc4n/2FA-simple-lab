<?php
session_start();


if (isset($_POST['otp_submit'])) {
 
    $entered_otp = $_POST['otp'];


    if ($_SESSION['otp'] == $entered_otp) {
        
        echo "OTP verified. Login successful!";
       
        unset($_SESSION['otp']);
        unset($_SESSION['email']);
    } else {

        echo "Incorrect OTP. Please try again!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
   <p>3 digit code are sended to mail</p>
    <form action="" method="post">
        <label for="otp">Enter OTP:</label><br>
        <input type="text" id="otp" name="otp" required><br><br>
        <input type="submit" name="otp_submit" value="Verify OTP">
    </form>
</body>
</html>
