<!DOCTYPE html>
<html>
<head>
    <title>Login with OTP</title>
</head>
<body>
    <h2>Login with OTP</h2>
    <form action="verify.php" method="post">
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <input type="submit" value="Send OTP">
    </form>
</body>
</html>
